# Apply to local

- windows `copy ./nvim/init.lua C:\Users\{userName}\AppData\Local\nvim`
